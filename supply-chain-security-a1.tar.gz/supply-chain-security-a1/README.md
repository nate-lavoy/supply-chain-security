# Python Rekor Monitor Template
This is template code for an assignment in Software Supply Chain Security class.
